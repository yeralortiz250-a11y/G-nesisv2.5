# Génesis 2.4 – asistente de voz para Android (se activa diciendo "Hola Génesis")

## Novedades de la 2.4
- **Ícono propio de Génesis**: el reactor de anillos cian sobre fondo oscuro, como un ícono adaptable (se ajusta al círculo, cuadrado o gota que use tu celular) y con versión monocroma para el modo de íconos temáticos de Android 13+.
  Está hecho con dibujos vectoriales (`res/drawable/ic_launcher_foreground.xml` y `ic_launcher_background.xml`), sin imágenes: para cambiar colores o formas basta editar esos dos archivos.
- Versión 2.4 (versionCode 14).

## Novedades de la 2.3
- **Desbloqueo con PATRÓN**: Menú → Desbloqueo → "Patrón de desbloqueo" → dibuja tu patrón en la cuadrícula (mínimo 4 puntos; se guarda cifrado, igual que el PIN).
  Génesis lo dibuja como un gesto sobre la cuadrícula de 9 puntos cuando una aplicación —o el propio celular al decir "desbloquea"— pide patrón. El PIN y el patrón pueden estar guardados a la vez; usa el que la pantalla pida.
  Un solo intento (5 fallos bloquean el celular o la app unos segundos). No escribe ni dibuja si la pantalla parece crear o cambiar un patrón o PIN, un pago o un código por SMS.
  Nota: Android dibuja los puntos del medio solos (de 1 a 3 pasa por el 2); el cuadro de dibujo hace lo mismo. Si tu patrón usa otra cuadrícula (4x4, 5x5) no funcionará.
- **Acceso a TODAS las apps instaladas**, de la Play Store o no (APK, Galaxy Store, de fábrica…): ahora también ve las de otros perfiles (trabajo, apps clonadas, segundo espacio)
  y las que no tienen ícono pero sí una pantalla que abrir.
  "¿Cuántas aplicaciones tengo?" → cuántas son de fábrica, de la Play Store y de otras fuentes. "¿Qué apps no son de la Play Store?" → las lista. "Abre" + cualquiera de ellas.
- Límites: no abre apps desactivadas ni las que Android esconde a propósito (Secure Folder o Espacio privado exigen tu autenticación propia); hay apps que bloquean la Accesibilidad y no dejan ver su pantalla de bloqueo.
- Versión 2.3 (versionCode 13).

## Novedades de la 2.2
- **Entra a cualquier aplicación**: "abre WhatsApp", "entra a Instagram", "abre ajustes", "ábreme la calculadora"… Encuentra la app aunque la digas con apodo ("wasap", "feis", "insta"),
  en español o inglés ("ajustes"/"settings") o con una falta de pronunciación. Si el celular estaba bloqueado, primero lo desbloquea con tu PIN.
- **Quita el bloqueo de la app con tu PIN**: al abrirla, Génesis mira la pantalla (Accesibilidad) y, si es una pantalla de bloqueo, escribe tu PIN guardado en Menú → Desbloqueo:
  teclado numérico, campo de PIN/contraseña, el aviso de huella pulsando "Usar PIN", o bloqueadores de apps. También por voz sobre lo que ya está en pantalla: "desbloquea la aplicación".
- **Un solo intento**: si la app sigue pidiendo clave (usa otro PIN), no lo repite para no bloquearla.
- **Protecciones**: no escribe el PIN si la pantalla parece crear o cambiar un PIN, un pago o tarjeta, un código de verificación por SMS, o un inicio de sesión con usuario/correo.
- **Límites reales**: no puede poner una huella o una cara ni dibujar un patrón; algunas apps (bancos, Secure Folder) ocultan o bloquean la Accesibilidad y no dejan ver su teclado; Android 10+ puede impedir abrir apps desde segundo plano (activa "Mostrar sobre otras apps").
  Ojo: cualquiera que diga la orden cerca de tu celular podrá abrir esas apps.
- "¿Qué has aprendido?" y "enséñame cómo sabes sumar" ya vienen desde la 1.7 (ver más abajo).
- Versión 2.2 (versionCode 12).

## Novedades de la 2.1
- **Menú más corto**: se quitaron "Canción" y "Código".
- **Bloquear y desbloquear por voz**: "Hola Génesis, desbloquea el celular" (enciende la pantalla, desliza y escribe tu PIN guardado en Menú → Desbloqueo; reintenta el deslizamiento y cada tecla)
  y "Hola Génesis, bloquea el celular / bloquea la pantalla / apaga la pantalla / pon el seguro" (necesita Accesibilidad y Android 9+).
- **Aprende al instante lo que no sabe**: si no sabe algo, busca 5 segundos; si no lo halla, **en ese momento** descarga el tema (Wikipedia en español e inglés y diccionario)
  a su base de datos en segundo plano, sin hablar sola. Sin internet lo anota y se pone a aprenderlo **solo en cuanto vuelva la conexión** (ya no espera la tanda de 30 minutos).
- **Alarmas y temporizadores corregidos**: "adelanta la alarma de las 7 diez minutos" (antes leía 7:10), "cambia el temporizador de 10 minutos a 15 minutos" (antes sumaba 25),
  "pon un temporizador" (antes creaba uno de 1 minuto; ahora pregunta cuánto), "temporizador de hora y media", y al cambiar una alarma ya no queda la vieja.
- Versión 2.1 (versionCode 11).

## Novedades de la 2.0
- **No habla sola**: ya no saluda al arrancar ni mantiene un "chat abierto". Solo contesta cuando le dices "Hola Génesis" + tu orden.
  Si dices solo "Hola Génesis", espera tu orden 8 segundos. Los recordatorios llegan como notificación, sin voz.
- **"Gracias"**: responde "Es un placer servir." y se apaga por completo (micrófono, notificación y servicio), igual que "sesión terminada".
  Para volver: toca el botón del micrófono de la app o "Comenzar sesión" en la notificación. Puedes decir "gracias" sin repetir su nombre
  durante unos segundos después de que te conteste, o "Hola Génesis, gracias" en cualquier momento.
- **Bloquear pantalla**: "bloquea la pantalla", "bloquea el celular" o "apaga la pantalla" (requiere Accesibilidad y Android 9+).
- **Menú con su propia animación**: el botón del menú gira a velocidad constante y ya no se mueve cuando ella habla.
- Versión 2.0 (versionCode 10).

## Alarmas y temporizadores personalizados
- Temporizador con cualquier tiempo (hasta 24 h): "temporizador de 1 hora 20 minutos y 30 segundos", "timer de 90 segundos", "temporizador de hora y media",
  "temporizador de tres cuartos de hora para la pasta". Si dices solo "pon un temporizador", pregunta cuánto y lo completas con "Hola Génesis, veinte minutos".
- Alarma a cualquier hora: "alarma a las 6 y cuarto de la mañana", "alarma a las 7:45", "alarma en 35 minutos", "alarma todos los días a las 7",
  "alarma de lunes a viernes a las 6 llamada gimnasio".
- Modificar: "cambia la alarma de las 7 a las 8", "adelanta la alarma de las 7 diez minutos", "atrasa la alarma de las 7 media hora", "cambia el temporizador a 25 minutos".
- Borrar: "borra la alarma de las 7", "cancela el temporizador", "muestra mis alarmas" (Android no deja leer ni borrar todas de golpe).
- Android no permite elegir una fecha para una alarma suelta: suena la próxima vez que sea esa hora.

## Barra de comandos
Menú → "Comando": escribe cualquier orden (igual que la dirías) y pulsa "Ejecutar" o Enter. No hace falta decir "Hola Génesis". "Crear atajo" guarda "cuando diga X, haz Y".
Botones del micrófono y del menú más grandes.

## Abrir y compilar
1. Instala Android Studio (Koala o más nuevo).
2. File → Open → carpeta `jarvis`.
3. Conecta tu celular (Depuración USB) y pulsa Run ▶.

> Los archivos `settings.gradle.kts` y `build.gradle.kts` de la raíz son los que enviaste
> (en este ZIP aparecen con esos nombres). Falta solo el wrapper de Gradle: Android Studio lo crea solo al abrir.

## Primer uso
1. Acepta los permisos (micrófono, llamadas, SMS, contactos, notificaciones).
2. Ajustes → Accesibilidad → **Génesis** → activar (esto le permite tocar y navegar).
3. Di **"Hola Génesis"** y después tu orden.

## Conversación y aprendizaje
- Sus respuestas son variadas: no contesta siempre igual.
- "me llamo Ana" / "mi comida favorita es la pizza" → lo recuerda ("¿cuál es mi comida favorita?").
- "cuando te diga buenas vibras responde a ti también" → aprende esa respuesta.
- "eso está mal, la respuesta es …" → se corrige y lo recuerda.
- Charla: saludos, "cuéntame un chiste", "dato curioso", "motívame", "gracias".
- Con clave de IA conversa con más libertad usando lo que sabe de ti. "Borrar" en el menú también borra tu perfil.

## Gestos, clic automático y desbloqueo
- "desliza hacia arriba/abajo/izquierda/derecha", "toca el centro/arriba/abajo", "doble toque", "mantén presionado".
- "clic automático en el centro cada 3 segundos" / "clic automático en aceptar" → repite el toque; "detén el clic automático" lo para (se apaga solo a los 10 min).
- "desbloquea": enciende la pantalla y la desliza; si guardaste tu PIN en Menú → Desbloqueo, lo escribe. Ojo: cualquiera que diga la orden podrá abrir el celular. Puede no funcionar en algunas marcas.
- Borrar memoria (menú o por voz: "borra tu memoria") exige siempre tu PIN o tu huella.

## Ejemplos de órdenes
- "baja el volumen" / "sube el volumen" / "volumen al 50" / "volumen al máximo" / "silencia"
- "busca recetas de pollo en Chrome" / "busca en Chrome el clima" / "abre Chrome y busca noticias"
- "pausa" / "siguiente canción" / "canción anterior"
- "Hola Génesis, llama a mami" (el contacto debe llamarse así) / "manda whatsapp a Ana diciendo voy en camino"
- "busca en google recetas" / "reproduce salsa en youtube" / "llévame a la farmacia"
- "qué hora es" / "cuánta batería tengo" / "ayuda" (lista lo que sabe hacer)
- "Jarvis, llama a Juan" / "manda mensaje a Ana diciendo voy en camino"
- "abre WhatsApp" / "abre cámara"
- "activa el modo avión" / "wifi" / "bluetooth" / "enciende la linterna"
- "sube el volumen" / "alarma a las 7 30"
- "atrás", "inicio", "notificaciones", "captura de pantalla", "bloquea"
- "toca aceptar" / "baja" / "escribe hola"
- "aprende sobre inflación" (con internet) / "recuerda que mi clave del gym es…"
- "cuando diga modo trabajo abre calendario"
- "¿qué es el stop loss?" (responde offline con sus lecciones)

## Menú (botón en forma de reactor, arriba a la derecha)
Cambiar voz (voces de Google) · Agregar comando · Cambiar color · Activar accesibilidad ·
Aprender de un texto (URL) · Borrar memoria (pide PIN/patrón/huella del celular).

## Límites de Android
- Android no permite a ninguna app normal "acceso total": todo pasa por permisos y por el servicio de Accesibilidad.
- Modo avión, Wi-Fi y Bluetooth: Jarvis abre el panel y pulsa el interruptor vía Accesibilidad (puede variar según marca).
- Pantalla bloqueada: el micrófono sigue escuchando, pero con el celular bloqueado Android impide abrir apps o tocar pantallas hasta que lo desbloquees.
- Desde Android 10 abrir apps en segundo plano puede ser bloqueado; en Ajustes de la app activa "Mostrar sobre otras apps" si pasa.
- Libros: añade solo textos de dominio público o con licencia libre (Project Gutenberg, etc.) con el menú "Aprender de un texto".
- Sin clave de API, la "IA" es una memoria con búsqueda por palabras clave, aprendizaje por Wikipedia, cálculos y reglas; no es un modelo de lenguaje.

## Aprendizaje autónomo (sin API)
Cada ~30 min, con internet y batería suficiente, Jarvis estudia solo en segundo plano (aunque cierres la app):
las preguntas que no supo contestar, y temas semilla (finanzas, trading, comunicación, lógica...) siguiendo
enlaces a temas relacionados de Wikipedia. Todo queda en su memoria para usarlo sin internet.
Android decide cuándo ejecuta estas tareas (ahorro de batería): no es instantáneo ni exacto.

## Memoria sin tope + nube
No hay límite fijo de datos. Menú → **Nube** → elige una carpeta de Google Drive / OneDrive / Dropbox (sin claves).
Cuando el celular tiene menos de 1 GB libre, menos de 10% libre o más de 20 000 datos aprendidos, Jarvis sube el 70% más
antiguo a esa carpeta y lo quita del celular, dejando un índice liviano. Si una pregunta no se responde localmente y hay
internet, busca en la nube. Sin carpeta conectada, los datos se quedan en el celular y, si quedan menos de 300 MB libres,
Jarvis pausa el aprendizaje para no llenarte el teléfono. El espacio total depende de tu nube (Drive da 15 GB gratis).

## Razonamiento y aprendizaje
- Local (sin internet): "cuánto es 15 por 8 más 20", "interés compuesto 1000 8 10", "tamaño de posición cuenta 1000 riesgo 2 stop 50", "riesgo beneficio entrada 100 stop 95 objetivo 115".
- Reglas: "si sube la inflación entonces suben las tasas" y luego "si sube la inflación qué pasa" (encadena varias reglas).
- Razonamiento profundo: menú → "Clave IA", pega tu clave de API de Anthropic. Con internet Jarvis razona con un modelo de lenguaje y guarda cada respuesta para usarla después sin internet.
- Arranque: pantalla "Tocar para iniciar" → secuencia animada con sonidos generados por código → menú radial animado (botón arriba a la derecha).

## Funciones nuevas (v1.1)
**Notificaciones y mensajes**
- "lee mis notificaciones" / "qué mensajes tengo" → lee en voz alta lo nuevo (necesita dar acceso a notificaciones a Génesis, una sola vez).
- "activa la lectura de notificaciones" → lee solo los mensajes que lleguen (WhatsApp, Telegram, SMS...). "desactiva la lectura de notificaciones" la apaga.
- "responde voy en camino" → responde al último mensaje desde su notificación. "borra mis notificaciones" las quita de la memoria de Génesis (nunca se guardan en disco).

**Clima, noticias y resumen**
- "mi ciudad es Madrid" (se guarda) · "cómo está el clima" · "clima mañana" · "va a llover en Lima".
- "noticias" (titulares de BBC Mundo) · "resumen del día" (fecha, clima, agenda, recordatorios, notificaciones y titulares).

**Recordatorios y agenda**
- "recuérdame en 20 minutos sacar la comida" · "recuérdame mañana a las 8 comprar pan" · "qué recordatorios tengo" · "borra mis recordatorios".
- "qué tengo hoy / mañana / esta semana" · "agenda reunión con Ana mañana a las 5" (se guarda en el calendario del celular con aviso 10 min antes).

**Modo conducción**
- "activa el modo conducción" / "estoy manejando" · "desactiva el modo conducción" / "ya llegué".
- Lee los mensajes al llegar y deja abierta la escucha para que digas "responde ...".
- Anuncia quién llama: "contesta" (con altavoz) o "rechaza" (rechaza y manda SMS "Estoy manejando, te llamo más tarde").
- Permisos nuevos: calendario, ubicación aproximada, teléfono y registro de llamadas. Acéptalos al iniciar.

## Cambios v1.2
**Menú:** el reactor del botón y el menú radial tienen su propio reloj y sus propias ondas; ya no se mueven ni saltan cuando ella habla (el bug era que su velocidad de giro dependía del micrófono).

**Interrupción:** si ella está hablando y dices "Hola Génesis…" o "para", "espera", "silencio", "detente", se calla al instante y te atiende. Descarta el eco de su propia voz.

**Cuando no sabe algo:** dice "déjame pensar…", busca en internet un máximo de 5 segundos (Wikipedia, DuckDuckGo y búsqueda de texto a la vez), te contesta y guarda la respuesta en su memoria para la próxima vez. Sin internet no espera: lo anota y lo estudia después. En pantalla muestra "pensando…".

**Aprender (menú):** escribe cualquier palabra o tema, o varios separados por coma ("comida, recetas de pollo, Wikipedia"). También por voz: "aprende sobre …". Si es una palabra suelta guarda además su definición. "Diccionario completo" descarga en segundo plano las entradas del Wiktionario en español (en una base de datos aparte); tarda días porque lo hace por tandas con internet y batería.
- "qué significa …" / "define …" → consulta el diccionario guardado (y lo busca si no está).

**Canciones:** "¿qué canción es esta?" → abre Shazam si lo tienes instalado. (La opción "Canción" ya no está en el menú.)

**Bloquear:** "bloquea la pantalla" / "bloquea el celular" / "apaga la pantalla" (necesita Accesibilidad activa y Android 9+).

**Aprende de cada conversación:** guarda lo que cuentas (gustos, dónde vives, trabajo, estudios, metas, mascotas, definiciones como "el sol es una estrella"), lo que busca en internet y un historial reciente. Pregúntale: "qué sabes de mí", "de qué hablamos", "qué cosas me gustan". "Borrar memoria" lo borra todo, incluido el diccionario.

## Cambios v1.3
**Micrófono persistente:** reutiliza un solo reconocedor (ya no lo destruye en cada frase), tolera pausas de hasta 4 s al hablar, se reinicia en ~0,1 s tras cada silencio, un "perro guardián" lo revive si Android lo deja colgado y un WakeLock evita que se duerma con la pantalla apagada. Después de cada intercambio sigue atendiéndote sin repetir "Hola Génesis" durante 20 s (`CONVERSATION_MS` en `JarvisService.kt`; ver v1.6).

**Sesión:**
- "sesión terminada" (también "termina la sesión", "cierra la sesión") → Génesis queda en silencio total: no habla (ni recordatorios ni notificaciones) y no ejecuta ninguna orden. Detiene el clic automático.
- "comenzar sesión" (también "iniciar sesión") → responde "Sesión iniciada, sistemas listos" y vuelve a la normalidad.
- El estado se conserva aunque reinicies el celular. Mientras la sesión está terminada, el micrófono sigue abierto solo para oír "comenzar sesión" (Android no permite otra forma de reactivarla por voz).

## Cambios v1.4
**Botón de micrófono** (abajo al centro de la pantalla principal): un toque = "comenzar sesión" (arranca Génesis si estaba apagada y responde "Sesión iniciada, sistemas listos"); mantenerlo presionado = "sesión terminada". Brilla con ondas si la sesión está activa y se ve gris y tachado si está terminada. Por voz siguen funcionando "sesión terminada" y "comenzar sesión".

**Internet abierto:** la app acepta cualquier sitio (http y https), sigue redirecciones, se identifica como navegador móvil y lee páginas completas.
- "abre wikipedia.org" / "entra a ejemplo punto com" → lo abre en el navegador.
- "lee la página bbc.com/mundo" / "resume el sitio ejemplo.com" → la descarga, lee el inicio en voz alta y guarda el texto en su cerebro.

**Cerebro virtual** (`Mind.kt`, base de datos `cerebro.db` en el celular, sin tope fijo): guarda
- *pensamientos*: cada conversación, razonamiento con IA y regla "si… entonces…";
- *cálculos*: matemáticas, interés compuesto, tamaño de posición y riesgo/beneficio con su resultado;
- *datos*: lo que le pides guardar y las páginas que lee.
Comandos: "qué hay en tu cerebro" · "últimos pensamientos" · "historial de cálculos" · "busca en tu cerebro vacunas" · "guarda en tu cerebro mi clave del gym es 1234" · "recuerda que …" (también lo guarda como dato). Menú → **Cerebro**: resumen y buscador. "Borrar memoria" también vacía el cerebro.

## Cambios v1.5
**Cerrar sesión = micrófono apagado de verdad.** "Sesión terminada" (o mantener presionado el botón del micrófono) destruye el reconocedor de voz, suelta el bloqueo de CPU y deja de hablar: el micrófono queda completamente apagado (desaparece el ícono de micrófono de Android). Como ya no escucha, **por voz no se puede reactivar**: se reactiva tocando el botón del micrófono o el botón "Comenzar sesión" de la notificación; responde "Sesión iniciada, sistemas listos". (Esto reemplaza lo dicho en v1.3 sobre "comenzar sesión" por voz.)

**Botón Aprender = aprendizaje automático masivo.** Al tocarlo arranca solo (sin escribir nada) y muestra el avance:
- Lee artículos COMPLETOS de Wikipedia en español (no solo el resumen), los trocea y los guarda en el cerebro (SQLite, sin tope fijo; se pausa si quedan menos de 300 MB libres).
- Se alimenta de: preguntas que no supo contestar, más de 400 temas semilla de todas las áreas, los enlaces de cada artículo (crece como telaraña) y artículos al azar (1 de cada 4) para abarcar de todo.
- También arranca el diccionario completo (Wiktionario).
- Por defecto solo con Wi-Fi (se puede cambiar en la misma ventana) y con batería suficiente. Sigue aunque cierres la app; Android decide cuándo ejecuta cada tanda.
- Todo lo aprendido se consulta al responder, también sin internet. "Borrar memoria" lo vacía.
- Voz: "aprende de todo" / "aprende solo" · "deja de aprender". El botón también permite "Escribir tema" (el aprendizaje manual de antes).

## Cambios v1.6
**Ya no se contesta sola.** El micrófono se pausa mientras Génesis habla y se reabre ~0,9 s después de que termina; además descarta el eco de lo último que dijo. (Consecuencia: ya no se la puede interrumpir hablando; para callarla, toca el botón del micrófono.)

**Filtro de ruido.** Solo atiende si oye "Génesis" o si estás dentro de la ventana de conversación (20 s tras cada intercambio, ajustable en `CONVERSATION_MS`), y descarta lo que el reconocedor marca con baja confianza. Android no tiene reconocimiento del hablante, así que no puede distinguir tu voz de otra: lo que hace es ignorar todo lo que no empiece con la palabra de activación. Para el máximo rigor, pon `CONVERSATION_MS = 0` y tendrás que decir "Hola Génesis" en cada orden.

**Cerrar sesión por voz:** "cierra la sesión", "cerrar sesión", "terminar sesión", "termina la sesión", "sesión terminada" o "fin de la sesión" (con o sin "Hola Génesis" y "por favor") cierran la sesión y apagan el micrófono. Funciona en cualquier momento, sin la ventana de conversación.


## Cambios v1.7
**"¿Qué has aprendido?"** (también "qué aprendiste", "qué has estudiado"): Génesis cuenta TODO lo que lleva aprendido: habilidades, cálculos resueltos, reglas, respuestas que le enseñaste, comandos propios, datos tuyos, conocimientos y temas estudiados (con los últimos), artículos de Wikipedia, palabras del diccionario, temas pendientes y líneas de código propio.

**Explica cómo lo aprendió y cómo se hace.** Después del resumen (o cuando quieras): "enséñame cómo sabes sumar", "cómo aprendiste a dividir", "explícame el interés compuesto", "cómo aprendes". Dentro de los 3 minutos siguientes al resumen basta con mencionar la cosa ("sumar", "reglas"). Cubre sumar, restar, multiplicar, dividir, potencias, porcentajes, interés compuesto, tamaño de posición, riesgo beneficio, reglas, correcciones, respuestas enseñadas, datos tuyos, búsqueda en internet, aprendizaje solo, diccionario, código, llamar, mensajes y volumen. Para temas que estudió: "cómo sabes de la inflación" / "qué sabes de la inflación" → dice de dónde y cuándo lo aprendió y qué guardó. (Con números, p. ej. "cuánto es 20 por ciento de 80", sigue calculando en vez de explicar.)

**Creador.** "¿Quién es tu creador?" (también "quién te creó", "quién te hizo", "quién te programó", "quién es tu padre") → "Geraldino Ortiz es mi creador y por así decirlo mi padre".

**Código propio (`CodeLab.kt`).** Mientras aprende, Génesis escribe código Kotlin y lo guarda en su cerebro (tabla `code`):
- un cálculo nuevo → la función (`sumar`, `restar`, `interesCompuesto`…) y la cuenta concreta;
- una regla "si… entonces…" → una línea `if`;
- una respuesta enseñada o corregida y cada comando propio → ramas de `when`;
- cada conocimiento o artículo nuevo → una entrada de un mapa (tope de 2000 para no llenar el celular);
- con clave de IA: "escribe código para ordenar una lista" → una función completa (usa tu clave; solo cuando lo pides).
Comandos: "qué código has escrito", "exporta tu código" (lo comparte o guarda como archivo Kotlin ordenado). (La opción "Código" ya no está en el menú.) "Borrar memoria" lo vacía con el resto del cerebro.

**Límite real:** Android no deja que una app instalada se compile ni se reescriba a sí misma, y ejecutar código generado sería peligroso. Por eso Génesis ESCRIBE y GUARDA su código, pero no lo ejecuta ni se modifica sola: lo exportas y, si te sirve, se añade al proyecto y se vuelve a compilar.


## Cambios v1.8 — escribe su código Y lo ejecuta
Génesis ahora **ejecuta** el código que escribe, en una "caja segura" (`GScript.kt`, lenguaje GenesisScript). Kotlin no se puede compilar ni ejecutar dentro de una app instalada, y dejar que código generado toque el teléfono sería peligroso; por eso ejecuta un lenguaje propio que solo hace cuentas, lógica y textos. **No puede** llamar, mandar mensajes, tocar la pantalla, leer archivos, usar internet ni borrar nada, y se corta solo si tarda más de 3 segundos o da demasiados pasos.

- **Verifica lo que aprende:** cada cuenta que resuelve la escribe como código y la ejecuta en la caja para comprobar que coincide con su respuesta (queda anotado "coincide" o "NO coincide").
- **Ejecutar sus funciones (sin clave):** "ejecuta sumar 15 y 8", "ejecuta interés compuesto 1000 8 10", "ejecuta riesgo beneficio 100 95 115".
- **Escribir un programa nuevo y ejecutarlo (con clave de IA):** "escribe código para calcular el área de un círculo de radio 5" (también "escribe y ejecuta código para…" o "… y ejecútalo"). El modelo escribe el programa en GenesisScript, Génesis lo ejecuta y dice el resultado; si da error, se lo devuelve al modelo para corregirlo (un reintento). Solo guarda lo que funcionó. Para código Kotlin (que NO se ejecuta, solo se guarda para exportar): "escribe código kotlin para…".
- **Volver a ejecutar:** "ejecuta tu último programa", o el botón **Ejecutar** en Menú → Código. "Exporta tu código" incluye también los programas ejecutables.

Ejemplo de GenesisScript (una instrucción por línea):
```
radio = 5
funcion area(r) = pi * r ^ 2
di redondea(area(radio))
```


## Cambios v1.9 — burbuja flotante
Un reactor pequeño flota sobre cualquier app mientras **no estés dentro de Génesis** (al entrar en la app se esconde sola; al salir, reaparece).
- **Activar/desactivar:** Menú → **Burbuja**, por voz ("activa la burbuja" / "quita la burbuja" / "cómo está la burbuja") o con el botón **Poner/Quitar burbuja** de la notificación de Génesis. Funciona dentro y fuera de la app.
- **Toque** = igual que el botón del micrófono (comienza la sesión si estaba terminada, o la calla si está hablando). **Pulsación larga** = abre la app. **Arrastrar** = la mueve y se pega al borde. Cian (o tu color) con la sesión activa, gris y tachada con la sesión terminada.
- Necesita el permiso **Mostrar sobre otras apps** (la primera vez Génesis abre la pantalla de Ajustes para darlo). Por defecto viene desactivada. Si reinicias el celular y estaba activada, reaparece sola.
- Todo lo que ya manipulaba del celular (llamadas, mensajes, volumen, toques, deslizar, desbloquear, etc.) sigue igual: no se quitó nada.
