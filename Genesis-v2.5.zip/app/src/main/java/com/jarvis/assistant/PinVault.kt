package com.jarvis.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Guarda el PIN de desbloqueo cifrado con una clave del Android Keystore (la clave nunca sale del celular). */
object PinVault {
    private const val ALIAS = "genesis_pin_key"

    private fun sp(c: Context) = c.getSharedPreferences("genesis_vault", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build()
        )
        return kg.generateKey()
    }

    fun has(c: Context): Boolean = sp(c).contains("pin")

    fun save(c: Context, pin: String?) {
        if (pin == null) { sp(c).edit().remove("pin").remove("iv").apply(); return }
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, key())
        val enc = ci.doFinal(pin.toByteArray())
        sp(c).edit()
            .putString("pin", Base64.encodeToString(enc, Base64.NO_WRAP))
            .putString("iv", Base64.encodeToString(ci.iv, Base64.NO_WRAP))
            .apply()
    }

    // ---- Patrón de desbloqueo: se guarda como los números de los puntos (1-9) en el orden en que se dibuja, cifrado igual que el PIN ----
    fun hasPattern(c: Context): Boolean = sp(c).contains("pat")

    fun savePattern(c: Context, seq: String?) {
        if (seq == null) { sp(c).edit().remove("pat").remove("pativ").apply(); return }
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(Cipher.ENCRYPT_MODE, key())
        val enc = ci.doFinal(seq.toByteArray())
        sp(c).edit()
            .putString("pat", Base64.encodeToString(enc, Base64.NO_WRAP))
            .putString("pativ", Base64.encodeToString(ci.iv, Base64.NO_WRAP))
            .apply()
    }

    fun loadPattern(c: Context): String? {
        return try {
            val encS = sp(c).getString("pat", null) ?: return null
            val ivS = sp(c).getString("pativ", null) ?: return null
            val ci = Cipher.getInstance("AES/GCM/NoPadding")
            ci.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(ivS, Base64.NO_WRAP)))
            String(ci.doFinal(Base64.decode(encS, Base64.NO_WRAP)))
        } catch (_: Exception) {
            null
        }
    }

    fun load(c: Context): String? {
        return try {
            val encS = sp(c).getString("pin", null) ?: return null
            val ivS = sp(c).getString("iv", null) ?: return null
            val enc = Base64.decode(encS, Base64.NO_WRAP)
            val iv = Base64.decode(ivS, Base64.NO_WRAP)
            val ci = Cipher.getInstance("AES/GCM/NoPadding")
            ci.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            String(ci.doFinal(enc))
        } catch (_: Exception) {
            null
        }
    }
}
