package com.jarvis.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED &&
            ContextCompat.checkSelfPermission(c, android.Manifest.permission.RECORD_AUDIO) == 0)
            try { ContextCompat.startForegroundService(c, Intent(c, JarvisService::class.java)) } catch (_: Exception) {}
    }
}
