package com.jarvis.assistant

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

fun withA(c: Int, a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), Color.red(c), Color.green(c), Color.blue(c))

/** Núcleo de energía animado (diseño propio): halo pulsante, 6 arcos giratorios, hexágono contrarrotante y satélite. */
fun drawCore(cv: Canvas, p: Paint, cx: Float, cy: Float, r: Float, color: Int, time: Long, speed: Float = 1f) {
    if (r <= 1f) return
    val a = (time * 0.06f * speed) % 360f
    val pulse = 0.5f + 0.5f * sin(time / 350.0).toFloat()
    p.style = Paint.Style.FILL
    p.shader = RadialGradient(cx, cy, r, intArrayOf(withA(color, 0.5f + 0.3f * pulse), withA(color, 0.12f), Color.TRANSPARENT),
        floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
    cv.drawCircle(cx, cy, r, p); p.shader = null
    p.style = Paint.Style.STROKE
    p.color = color; p.strokeWidth = r * 0.07f; cv.drawCircle(cx, cy, r * 0.96f, p)
    p.strokeWidth = r * 0.09f; p.color = withA(color, 0.9f)
    val rect = RectF(cx - r * 0.78f, cy - r * 0.78f, cx + r * 0.78f, cy + r * 0.78f)
    for (i in 0 until 6) cv.drawArc(rect, a + i * 60f, 38f, false, p)
    p.strokeWidth = r * 0.05f; p.color = withA(color, 0.8f)
    val path = Path()
    for (i in 0..6) {
        val ang = Math.toRadians((-a * 1.5f + i * 60f).toDouble())
        val x = cx + cos(ang).toFloat() * r * 0.5f; val y = cy + sin(ang).toFloat() * r * 0.5f
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    cv.drawPath(path, p)
    p.style = Paint.Style.FILL
    p.color = withA(color, 0.7f + 0.3f * pulse); cv.drawCircle(cx, cy, r * (0.16f + 0.05f * pulse), p)
    val o = Math.toRadians((-a * 2.2f).toDouble())
    cv.drawCircle(cx + cos(o).toFloat() * r * 0.96f, cy + sin(o).toFloat() * r * 0.96f, r * 0.06f, p)
    p.style = Paint.Style.STROKE
}


fun lighten(c: Int, f: Float) = Color.rgb(
    (Color.red(c) + (255 - Color.red(c)) * f).toInt(),
    (Color.green(c) + (255 - Color.green(c)) * f).toInt(),
    (Color.blue(c) + (255 - Color.blue(c)) * f).toInt())

/** Reactor Arc animado (botón del menú): aro metálico, 10 bobinas giratorias, triángulo central y chispa orbitando. */
fun drawReactor(cv: Canvas, p: Paint, cx: Float, cy: Float, r: Float, color: Int, time: Long, speed: Float = 1f) {
    if (r <= 1f) return
    val pulse = 0.5f + 0.5f * sin(time / 280.0).toFloat()
    val rot = (time * 0.04f * speed) % 360f
    val light = lighten(color, 0.7f)
    p.style = Paint.Style.FILL
    p.shader = RadialGradient(cx, cy, r * 1.3f, intArrayOf(withA(color, 0.6f + 0.3f * pulse), withA(color, 0.18f), Color.TRANSPARENT),
        floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
    cv.drawCircle(cx, cy, r * 1.3f, p); p.shader = null
    p.color = withA(Color.BLACK, 0.8f); cv.drawCircle(cx, cy, r * 0.98f, p)
    p.style = Paint.Style.STROKE
    p.color = withA(light, 0.95f); p.strokeWidth = r * 0.12f; cv.drawCircle(cx, cy, r * 0.92f, p)
    p.color = withA(color, 0.9f); p.strokeWidth = r * 0.03f; cv.drawCircle(cx, cy, r * 0.82f, p)
    val rc = r * 0.62f
    val rect = RectF(cx - rc, cy - rc, cx + rc, cy + rc)
    p.strokeWidth = r * 0.22f; p.color = withA(light, 0.65f + 0.3f * pulse)
    for (i in 0 until 10) cv.drawArc(rect, rot * 0.35f + i * 36f, 24f, false, p)
    p.strokeWidth = r * 0.05f; p.color = withA(color, 0.95f); cv.drawCircle(cx, cy, r * 0.42f, p)
    val path = Path()
    for (i in 0..2) {
        val a = Math.toRadians((-rot * 0.6f + i * 120f - 90f).toDouble())
        val x = cx + cos(a).toFloat() * r * 0.33f; val y = cy + sin(a).toFloat() * r * 0.33f
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    p.style = Paint.Style.FILL; p.color = withA(Color.WHITE, 0.55f + 0.4f * pulse); cv.drawPath(path, p)
    p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.04f; p.color = withA(light, 1f); cv.drawPath(path, p)
    val o = Math.toRadians((-rot * 1.6f).toDouble())
    p.style = Paint.Style.FILL; p.color = withA(Color.WHITE, 0.9f)
    cv.drawCircle(cx + cos(o).toFloat() * r * 0.92f, cy + sin(o).toFloat() * r * 0.92f, r * 0.06f, p)
    p.style = Paint.Style.STROKE
}

/** Pantalla principal: espera ("tocar para iniciar") → secuencia de arranque → HUD en vivo. */
class HudView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    var phase = 0
    private var bootT0 = 0L
    var onStartTap: (() -> Unit)? = null
    var onBootDone: (() -> Unit)? = null
    var color = Prefs.color(c)

    private val rnd = java.util.Random(7)
    private val n = 70
    private val px = FloatArray(n) { rnd.nextFloat() }
    private val py = FloatArray(n) { rnd.nextFloat() }
    private val ps = FloatArray(n) { 0.4f + rnd.nextFloat() }
    private val bx = FloatArray(16) { rnd.nextFloat() }
    private val by = FloatArray(16) { rnd.nextFloat() }
    private val bs = FloatArray(16) { rnd.nextFloat() }
    private val bootLines = listOf("INICIANDO NÚCLEO", "CARGANDO MEMORIA", "SINTONIZANDO VOZ", "ENLAZANDO SISTEMAS", "GÉNESIS EN LÍNEA")

    /**
     * Reloj de animación RELATIVO al arranque de la vista. Antes se usaba System.currentTimeMillis() (≈1,7·10¹²) multiplicado
     * por un Float: un Float solo guarda ~7 cifras, así que los ángulos se "congelaban" y saltaban cada ~2 minutos
     * (por eso los aros casi no se movían). Con un tiempo pequeño la rotación vuelve a ser continua.
     */
    private val clock0 = System.currentTimeMillis()
    private fun clock() = System.currentTimeMillis() - clock0
    private val fx = Futuro()

    fun beginBoot() { if (phase == 0) { phase = 1; bootT0 = clock() } }

    private val tick = object : Runnable { override fun run() { invalidate(); postOnAnimation(this) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(tick); Hud.listener = { } }
    override fun onDetachedFromWindow() { removeCallbacks(tick); Hud.listener = null; super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (phase == 0 && e.action == MotionEvent.ACTION_UP) onStartTap?.invoke()
        return phase == 0
    }

    private fun background(cv: Canvas, now: Long, al: Float) {
        cv.drawColor(Color.parseColor("#020A10"))
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(width / 2f, height * 0.42f, height * 0.6f, withA(color, 0.16f * al), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = withA(color, 0.07f * al)
        val g = 60
        var x = 0; while (x < width) { cv.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), p); x += g }
        var y = 0; while (y < height) { cv.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), p); y += g }
        // trazos tipo plano técnico
        p.strokeWidth = 1.5f; p.color = withA(color, 0.10f * al)
        for (i in 0 until 16) {
            val bx0 = bx[i] * width; val by0 = by[i] * height; val sz = 20f + bs[i] * 110f
            when (i % 3) {
                0 -> cv.drawCircle(bx0, by0, sz, p)
                1 -> cv.drawRect(bx0, by0, bx0 + sz * 1.6f, by0 + sz, p)
                else -> cv.drawLine(bx0, by0, bx0 + sz * 2f, by0, p)
            }
        }
        val sy = (now / 7 % height).toFloat()
        p.strokeWidth = 3f; p.color = withA(color, 0.10f * al); cv.drawLine(0f, sy, width.toFloat(), sy, p)
        p.style = Paint.Style.FILL; p.color = withA(color, 0.5f * al)
        for (i in 0 until n) {
            val yy = ((py[i] - now * ps[i] * 0.00004f) % 1f + 1f) % 1f
            cv.drawCircle(px[i] * width, yy * height, 2.5f * ps[i], p)
        }
        p.style = Paint.Style.STROKE
    }

    /** HUD estilo J.A.R.V.I.S.: aro exterior con marcas, banda segmentada giratoria, arco ámbar con puntos y aros interiores. */
    private fun rings(cv: Canvas, cx: Float, cy: Float, r: Float, ang: Float, al: Float, glow: Float, sweepExtra: Float) {
        val amber = Color.parseColor("#FFB300")
        val light = lighten(color, 0.55f)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.2f, withA(color, (0.22f + glow * 0.35f) * al), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r * 1.2f, p); p.shader = null
        p.style = Paint.Style.STROKE
        // aro exterior doble
        p.color = withA(light, al); p.strokeWidth = 6f; cv.drawCircle(cx, cy, r, p)
        p.color = withA(color, 0.6f * al); p.strokeWidth = 2f; cv.drawCircle(cx, cy, r * 0.965f, p)
        // marcas
        p.strokeWidth = 2f; p.color = withA(color, 0.8f * al)
        for (i in 0 until 180) {
            val a = Math.toRadians(i * 2.0 + ang * 0.15)
            val len = if (i % 5 == 0) r * 0.07f else r * 0.035f
            val r1 = r * 0.93f
            cv.drawLine(cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1,
                cx + cos(a).toFloat() * (r1 - len), cy + sin(a).toFloat() * (r1 - len), p)
        }
        // banda segmentada gruesa (barrido giratorio)
        val rb = r * 0.78f
        val rect = RectF(cx - rb, cy - rb, cx + rb, cy + rb)
        p.strokeWidth = r * 0.15f
        val sweep = 200f + sweepExtra
        val start = (ang * 0.6f) % 360f
        for (i in 0 until 60) {
            val a0 = i * 6f
            val rel = ((a0 - start) % 360f + 360f) % 360f
            val fade = if (rel < sweep) 0.35f + 0.65f * (1f - rel / sweep) else 0.10f
            p.color = withA(color, fade * al)
            cv.drawArc(rect, a0, 4.6f, false, p)
        }
        // arco ámbar con puntos
        val ra = r * 0.64f
        val ar = RectF(cx - ra, cy - ra, cx + ra, cy + ra)
        val aa = -ang * 1.3f
        p.strokeWidth = 5f; p.color = withA(amber, al)
        cv.drawArc(ar, aa, 46f, false, p)
        p.style = Paint.Style.FILL
        for (k in 1..4) {
            val d = Math.toRadians((aa + 46f + k * 9f).toDouble())
            cv.drawCircle(cx + cos(d).toFloat() * ra, cy + sin(d).toFloat() * ra, 3.5f, p)
        }
        p.style = Paint.Style.STROKE
        // aros interiores
        p.strokeWidth = 5f; p.color = withA(light, al); cv.drawCircle(cx, cy, r * 0.56f, p)
        p.strokeWidth = 1.5f; p.color = withA(color, 0.55f * al); cv.drawCircle(cx, cy, r * 0.5f + glow * 10f, p)
        p.strokeWidth = 2.5f; p.color = withA(color, 0.7f * al)
        val ri = r * 0.44f
        val ir = RectF(cx - ri, cy - ri, cx + ri, cy + ri)
        for (k in 0 until 3) cv.drawArc(ir, ang * 0.8f + k * 120f, 70f, false, p)
    }

    /** Título del centro, como en la imagen de referencia. */
    private fun title(cv: Canvas, cx: Float, cy: Float, r: Float, al: Float, now: Long = -1L) {
        t.typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
        t.textSize = r * 0.1f; t.letterSpacing = 0.06f
        // destello "glitch" holográfico: cada ~4 s el título se desdobla en rojo y cian durante 0,17 s
        if (now >= 0L && now % 4300L < 170L) {
            val off = 3f + ((now / 45L) % 3L) * 3f
            t.color = withA(Color.rgb(255, 40, 90), 0.55f * al); cv.drawText("G.É.N.E.S.I.S.", cx + off, cy + t.textSize / 3, t)
            t.color = withA(Color.rgb(0, 255, 255), 0.55f * al); cv.drawText("G.É.N.E.S.I.S.", cx - off, cy + t.textSize / 3, t)
        }
        t.setShadowLayer(18f, 0f, 0f, withA(color, al))
        t.color = withA(Color.WHITE, al)
        cv.drawText("G.É.N.E.S.I.S.", cx, cy + t.textSize / 3, t)
        t.clearShadowLayer()
    }

    override fun onDraw(cv: Canvas) {
        val now = clock()
        val cx = width / 2f; val cy = height * 0.42f; val r = width * 0.42f
        val ang = (now * 0.045f) % 360f
        t.typeface = Typeface.create("sans-serif-light", Typeface.BOLD)

        when (phase) {
            0 -> {
                background(cv, now, 0.7f)
                val br = 0.5f + 0.5f * sin(now / 500.0).toFloat()
                val rr0 = r * 0.8f * (0.97f + 0.03f * br)
                fx.under(cv, width.toFloat(), height.toFloat(), cx, cy, rr0, color, now, false)
                rings(cv, cx, cy, rr0, ang * 0.4f, 0.45f + 0.45f * br, br * 0.5f, 0f)
                title(cv, cx, cy, rr0, 0.6f + 0.4f * br, now)
                t.typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
                t.color = withA(Color.WHITE, 0.5f + 0.5f * br); t.textSize = 50f; t.letterSpacing = 0.18f
                cv.drawText("TOCAR PARA INICIAR", cx, cy + rr0 + 150f, t)
            }
            1 -> {
                background(cv, now, 1f)
                val pr = ((now - bootT0) / 4000f).coerceIn(0f, 1f)
                val ease = 1f - (1f - pr).pow(3)
                val rr = r * (0.5f + 0.5f * ease)
                fx.under(cv, width.toFloat(), height.toFloat(), cx, cy, rr, color, now, true)
                rings(cv, cx, cy, rr, ang * (1f + (1f - pr) * 6f), min(1f, pr * 3f + 0.35f), 0.4f + 0.6f * (1f - pr), 120f * (1f - pr))
                // onda expansiva
                p.style = Paint.Style.STROKE; p.strokeWidth = 4f
                val sw = r * 1.7f * ease; p.color = withA(color, (1f - pr) * 0.8f); cv.drawCircle(cx, cy, sw, p)
                val sw2 = r * 1.7f * (ease * 0.7f); p.color = withA(color, (1f - pr) * 0.5f); cv.drawCircle(cx, cy, sw2, p)
                // progreso
                p.strokeWidth = 10f; p.color = withA(Color.parseColor("#FFB300"), 0.9f)
                val o = r * 1.2f
                cv.drawArc(RectF(cx - o, cy - o, cx + o, cy + o), -90f, 360f * pr, false, p)
                t.letterSpacing = 0.2f; t.textSize = 40f; t.typeface = Typeface.MONOSPACE
                val count = (pr * bootLines.size).toInt().coerceAtMost(bootLines.size - 1) + 1
                for (i in 0 until count) {
                    t.color = withA(if (i == count - 1) Color.WHITE else color, if (i == count - 1) 1f else 0.6f)
                    cv.drawText("> " + bootLines[i], cx, cy + r * 1.3f + 50f + i * 54f, t)
                }
                title(cv, cx, cy, rr, 1f)
                if (pr >= 1f) { phase = 2; onBootDone?.invoke() }
            }
            else -> {
                background(cv, now, 1f)
                val glow = Hud.rms.coerceIn(0f, 10f) / 10f
                val extra = if (Hud.isListening) 50f + glow * 120f else 0f
                fx.under(cv, width.toFloat(), height.toFloat(), cx, cy, r, color, now, Hud.thinking)
                rings(cv, cx, cy, r, ang, 1f, glow, extra)
                fx.over(cv, width.toFloat(), height.toFloat(), cx, cy, r, color, now, Hud.isListening, Hud.thinking, glow)
                // satélites orbitando
                p.style = Paint.Style.FILL; p.color = withA(color, 0.95f)
                for (k in 0 until 3) {
                    val a = Math.toRadians((ang * (1.3 + k * 0.4) + k * 120.0))
                    cv.drawCircle(cx + cos(a).toFloat() * r * 1.07f, cy + sin(a).toFloat() * r * 1.07f, 7f, p)
                }
                p.style = Paint.Style.STROKE
                title(cv, cx, cy, r, 1f, now)
                t.typeface = Typeface.DEFAULT; t.letterSpacing = 0f
                t.textSize = 38f; t.color = color
                cv.drawText(if (Hud.thinking) "pensando…" else if (Hud.isListening) "escuchando…" else "en espera", cx, cy + r * 1.25f + 60f, t)      // más abajo: deja libres los aros nuevos
                t.color = Color.LTGRAY; t.textSize = 34f
                cv.drawText(Hud.lastHeard.take(48), cx, cy + r * 1.25f + 130f, t)
                t.color = Color.WHITE
                wrap(Hud.lastSaid, 42).forEachIndexed { i, l -> cv.drawText(l, cx, cy + r * 1.25f + 210f + i * 44f, t) }
            }
        }
    }

    private fun wrap(s: String, n: Int): List<String> {
        val out = mutableListOf<String>(); var cur = ""
        for (w in s.split(" ")) { if ((cur + " " + w).length > n) { out.add(cur.trim()); cur = w } else cur += " $w" }
        if (cur.isNotBlank()) out.add(cur.trim()); return out.take(5)
    }
}

/**
 * Reloj propio del menú: avanza a velocidad CONSTANTE y no depende de la voz ni del micrófono.
 * (El bug anterior: el botón cambiaba su velocidad de giro con Hud.rms; como la rotación es tiempo × velocidad,
 *  cada cambio de velocidad hacía "saltar" el reactor mientras ella hablaba.)
 */
object MenuAnim {
    private val t0 = android.os.SystemClock.uptimeMillis()
    fun t(): Long = android.os.SystemClock.uptimeMillis() - t0
}

/** Botón-menú: reactor arc animado (arriba a la derecha), con su propia animación aparte de la interfaz. */
class CoreButton(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable { override fun run() { invalidate(); postOnAnimation(this) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val col = Prefs.color(context); val t = MenuAnim.t()
        val cx = width / 2f; val cy = height / 2f; val r = width * 0.36f
        // ondas expansivas propias del botón (ciclo fijo de 2,4 s)
        p.style = Paint.Style.STROKE
        for (k in 0 until 2) {
            val f = ((t + k * 1200L) % 2400L) / 2400f
            p.strokeWidth = 2f; p.color = withA(col, (1f - f) * 0.45f)
            cv.drawCircle(cx, cy, r * (1f + 0.38f * f), p)
        }
        drawReactor(cv, p, cx, cy, r, col, t, 1.2f)
    }
}

/**
 * Botón de micrófono (abajo, centrado): toque = "comenzar sesión"; pulsación larga = "sesión terminada".
 * Brilla con ondas cuando la sesión está activa y se ve apagado y tachado cuando está terminada.
 */
class MicButton(c: Context) : View(c) {
    var active = true
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable { override fun run() { invalidate(); postOnAnimation(this) } }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val col = if (active) Prefs.color(context) else Color.parseColor("#777777")
        val t = MenuAnim.t()
        val cx = width / 2f; val cy = height / 2f; val r = width * 0.389f      // vista de 72 dp → círculo de 56 dp
        p.style = Paint.Style.STROKE
        if (active) for (k in 0 until 2) {
            val f = ((t + k * 1200L) % 2400L) / 2400f
            p.strokeWidth = 2f; p.color = withA(col, (1f - f) * 0.45f)
            cv.drawCircle(cx, cy, r * (1f + 0.28f * f), p)
        }
        p.style = Paint.Style.FILL; p.color = withA(Color.BLACK, 0.8f); cv.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.08f; p.color = withA(col, 0.95f); cv.drawCircle(cx, cy, r, p)
        // micrófono: cápsula + soporte + base
        p.style = Paint.Style.FILL; p.color = col
        cv.drawRoundRect(RectF(cx - r * 0.17f, cy - r * 0.52f, cx + r * 0.17f, cy + r * 0.10f), r * 0.17f, r * 0.17f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.07f; p.strokeCap = Paint.Cap.ROUND
        cv.drawArc(RectF(cx - r * 0.34f, cy - r * 0.40f, cx + r * 0.34f, cy + r * 0.28f), 0f, 180f, false, p)
        cv.drawLine(cx, cy + r * 0.28f, cx, cy + r * 0.52f, p)
        cv.drawLine(cx - r * 0.18f, cy + r * 0.52f, cx + r * 0.18f, cy + r * 0.52f, p)
        if (!active) { p.color = Color.parseColor("#FF5252"); cv.drawLine(cx - r * 0.62f, cy - r * 0.62f, cx + r * 0.62f, cy + r * 0.62f, p) }
        p.strokeCap = Paint.Cap.BUTT
    }
}

/** Menú radial a pantalla completa: se despliega desde un núcleo central grande. */
class RadialMenuView(c: Context) : View(c) {
    data class Item(val glyph: String, val label: String)
    var items: List<Item> = emptyList()
    var onPick: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private var prog = 0f
    private var anim: ValueAnimator? = null

    init { visibility = GONE }

    fun open() {
        visibility = VISIBLE
        anim?.cancel()
        anim = ValueAnimator.ofFloat(prog, 1f).apply {
            duration = 600; interpolator = OvershootInterpolator(1.1f)
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }; start()
        }
        Sfx.menuOpen()
    }

    fun close(after: (() -> Unit)? = null) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(prog, 0f).apply {
            duration = 320
            addUpdateListener { prog = (it.animatedValue as Float).coerceAtLeast(0f); invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) { visibility = GONE; after?.invoke() }
            }); start()
        }
    }

    private fun geometry(i: Int): Triple<Float, Float, Float> {
        val cx = width / 2f; val cy = height * 0.46f
        val ring = min(width, height) * 0.36f * prog
        val a = Math.toRadians(-90.0 + i * 360.0 / items.size)
        return Triple(cx + cos(a).toFloat() * ring, cy + sin(a).toFloat() * ring, width * 0.085f)
    }

    override fun onDraw(cv: Canvas) {
        if (prog <= 0.001f || items.isEmpty()) return
        val col = Prefs.color(context); val now = MenuAnim.t()   // reloj propio del menú, independiente de la voz
        val cx = width / 2f; val cy = height * 0.46f
        cv.drawColor(Color.argb((235 * prog.coerceIn(0f, 1f)).toInt(), 0, 0, 0))
        // anillo de guía giratorio
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = withA(col, 0.35f * prog)
        val gr = min(width, height) * 0.36f * prog
        cv.drawCircle(cx, cy, gr, p)
        p.strokeWidth = 6f; p.color = withA(col, 0.6f * prog)
        val ga = (now * 0.03f) % 360f
        for (k in 0 until 4) cv.drawArc(RectF(cx - gr, cy - gr, cx + gr, cy + gr), ga + k * 90f, 30f, false, p)

        // pulsos que salen del reactor central (animación propia del menú)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f
        for (k in 0 until 3) {
            val f = ((now + k * 1000L) % 3000L) / 3000f
            p.color = withA(col, (1f - f) * 0.35f * prog)
            cv.drawCircle(cx, cy, width * 0.16f * prog + gr * 0.9f * f, p)
        }
        drawReactor(cv, p, cx, cy, width * 0.16f * prog, col, now, 1.2f)

        for (i in items.indices) {
            val ip = ((prog * 1.5f) - i * 0.08f).coerceIn(0f, 1f)
            if (ip <= 0f) continue
            val (x, y, r0) = geometry(i); val r = r0 * ip
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = withA(col, 0.4f * ip)
            cv.drawLine(cx, cy, x, y, p)
            p.style = Paint.Style.FILL; p.color = withA(Color.BLACK, 0.85f); cv.drawCircle(x, y, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = withA(col, ip); cv.drawCircle(x, y, r, p)
            p.strokeWidth = 2f; p.color = withA(col, 0.5f * ip); cv.drawCircle(x, y, r * 0.8f, p)
            t.color = withA(Color.WHITE, ip); t.textSize = r * 0.8f; t.typeface = Typeface.DEFAULT_BOLD
            cv.drawText(items[i].glyph, x, y + r * 0.28f, t)
            t.color = withA(col, ip); t.textSize = 30f * ip; t.typeface = Typeface.DEFAULT
            cv.drawText(items[i].label, x, y + r + 40f, t)
        }
        postInvalidateOnAnimation()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (visibility != VISIBLE) return false
        if (e.action == MotionEvent.ACTION_UP && prog > 0.7f) {
            for (i in items.indices) {
                val (x, y, r) = geometry(i)
                if (hypot(e.x - x, e.y - y) < r * 1.4f) { Sfx.select(); onPick?.invoke(i); return true }
            }
            close()
        }
        return true
    }
}
