package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager

/**
 * BURBUJA FLOTANTE de Génesis: un reactor pequeño que flota sobre cualquier app.
 *  - Solo se ve cuando NO estás dentro de la app de Génesis (al entrar se esconde sola, al salir reaparece).
 *  - Se activa/desactiva desde el menú (botón "Burbuja"), por voz ("activa la burbuja" / "quita la burbuja")
 *    o con el botón de la notificación, así que funciona dentro y fuera de la app.
 *  - Toque = igual que el botón del micrófono (comienza la sesión si estaba apagada, o la calla si está hablando).
 *    Pulsación larga = abre la app. Arrastrarla la mueve y se pega al borde de la pantalla.
 *  - Es cian (o el color que elijas) con la sesión activa y gris con la sesión terminada.
 *  - Necesita el permiso "Mostrar sobre otras apps" (Android lo pide una sola vez).
 */
object Bubble {
    /** true mientras la pantalla de Génesis está a la vista; la pone MainActivity. */
    @Volatile var appVisible = false

    private val main = Handler(Looper.getMainLooper())
    private var view: BubbleView? = null

    fun canDraw(c: Context): Boolean = Settings.canDrawOverlays(c)

    /** Activa o desactiva la burbuja y devuelve lo que Génesis debe decir. */
    fun setEnabled(c: Context, on: Boolean): String {
        Prefs.setBubbleOn(c, on)
        sync(c)
        JarvisService.instance?.refreshNotif()      // el botón de la notificación cambia entre "Poner" y "Quitar" burbuja
        if (!on) return "Burbuja desactivada."
        if (!canDraw(c)) {
            try {
                c.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {}
            return "Para la burbuja necesito el permiso Mostrar sobre otras apps. Actívalo para Génesis y la burbuja aparecerá cuando salgas de mi app."
        }
        return "Burbuja activada. Aparece cuando no estás dentro de mi app."
    }

    fun toggle(c: Context): String = setEnabled(c, !Prefs.bubbleOn(c))

    fun status(c: Context): String =
        if (!Prefs.bubbleOn(c)) "La burbuja está desactivada. Di: activa la burbuja."
        else if (!canDraw(c)) "La burbuja está activada, pero falta el permiso Mostrar sobre otras apps."
        else "La burbuja está activada."

    /** Muestra u oculta la burbuja según: está activada, no estás dentro de la app y hay permiso. */
    fun sync(c: Context) {
        val app = c.applicationContext
        main.post { apply(app) }
    }

    private fun apply(c: Context) {
        val want = Prefs.bubbleOn(c) && !appVisible && canDraw(c)
        if (!want) { remove(c); return }
        if (view == null) add(c) else view?.invalidate()
    }

    private fun remove(c: Context) {
        val v = view ?: return
        view = null
        try { (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v) } catch (_: Exception) {}
    }

    private fun add(c: Context) {
        try {
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val d = c.resources.displayMetrics
            val size = (56 * d.density).toInt()
            val p = WindowManager.LayoutParams(
                size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.x = Prefs.bubbleX(c).let { if (it < 0) d.widthPixels - size else it.coerceIn(0, d.widthPixels - size) }
            p.y = Prefs.bubbleY(c).let { if (it < 0) d.heightPixels / 3 else it.coerceIn(0, d.heightPixels - size) }
            val v = BubbleView(c, wm, p, size)
            wm.addView(v, p)
            view = v
        } catch (_: Exception) { view = null }
    }

    private class BubbleView(
        private val ctx: Context, private val wm: WindowManager,
        private val lp: WindowManager.LayoutParams, private val size: Int
    ) : View(ctx) {

        private val dens = ctx.resources.displayMetrics.density
        private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * dens }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f * dens; strokeCap = Paint.Cap.ROUND }
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }
        private val box = RectF()
        private var ang = 0f

        private val tick = object : Runnable {
            override fun run() { ang = (ang + 3f) % 360f; invalidate(); postOnAnimationDelayed(this, 33) }
        }

        override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimationDelayed(tick, 33) }
        override fun onDetachedFromWindow() { removeCallbacks(tick); removeCallbacks(longPress); super.onDetachedFromWindow() }

        override fun onDraw(cv: Canvas) {
            val on = Prefs.sessionOn(ctx)
            val col = if (on) Prefs.color(ctx) else 0xFF8A8A8A.toInt()
            val cx = width / 2f; val cy = height / 2f; val r = width / 2f - 4f * dens
            fill.color = (col and 0x00FFFFFF) or (0x44 shl 24)
            cv.drawCircle(cx, cy, r, fill)
            ring.color = col; cv.drawCircle(cx, cy, r, ring)
            arc.color = col
            box.set(cx - r + 5f * dens, cy - r + 5f * dens, cx + r - 5f * dens, cy + r - 5f * dens)
            cv.drawArc(box, ang, 70f, false, arc)
            cv.drawArc(box, ang + 180f, 70f, false, arc)
            txt.color = Color.WHITE; txt.textSize = r * 0.95f
            cv.drawText("G", cx, cy + txt.textSize * 0.34f, txt)
            if (!on) { ring.color = Color.WHITE; cv.drawLine(cx - r * 0.6f, cy + r * 0.6f, cx + r * 0.6f, cy - r * 0.6f, ring) }
        }

        // ---- Toque, pulsación larga y arrastre ----
        private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
        private var moved = false; private var longFired = false
        private val longPress = Runnable {
            longFired = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            try { ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) } catch (_: Exception) {}
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false; longFired = false
                    postDelayed(longPress, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && Math.hypot(dx.toDouble(), dy.toDouble()) > slop) { moved = true; removeCallbacks(longPress) }
                    if (moved) {
                        lp.x = (startX + dx).toInt(); lp.y = (startY + dy).toInt()
                        try { wm.updateViewLayout(this, lp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    removeCallbacks(longPress)
                    if (moved) snap()
                    else if (!longFired) {
                        performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        JarvisService.begin(ctx)             // igual que el botón del micrófono
                    }
                }
                MotionEvent.ACTION_CANCEL -> removeCallbacks(longPress)
            }
            return true
        }

        /** Al soltar, se pega al borde más cercano y guarda su posición. */
        private fun snap() {
            val d = ctx.resources.displayMetrics
            lp.x = if (lp.x + size / 2 < d.widthPixels / 2) 0 else d.widthPixels - size
            lp.y = lp.y.coerceIn(0, d.heightPixels - size)
            try { wm.updateViewLayout(this, lp) } catch (_: Exception) {}
            Prefs.setBubblePos(ctx, lp.x, lp.y)
        }
    }
}
