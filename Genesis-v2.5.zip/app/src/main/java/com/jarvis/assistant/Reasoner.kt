package com.jarvis.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Razonador de Jarvis, en tres capas:
 * 1) Local: matemáticas, cálculos financieros/trading y reglas "si... entonces..." encadenadas.
 * 2) Memoria: usa lo aprendido como contexto.
 * 3) Con internet y clave de API: consulta un modelo de lenguaje (Claude) para razonar a fondo
 *    y guarda cada respuesta en su memoria para poder usarla sin internet después.
 */
class Reasoner(private val ctx: Context, private val brain: Brain) {

    private val rf get() = ctx.getFileStreamPath("rules.json")
    private val rules = mutableListOf<Pair<String, String>>()
    private val history = mutableListOf<Pair<String, String>>()   // (user, assistant)

    init {
        if (rf.exists()) try {
            val a = JSONArray(rf.readText())
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); rules.add(o.getString("p") to o.getString("c")) }
        } catch (_: Exception) {}
    }

    private fun saveRules() {
        rf.writeText(JSONArray().also { a -> rules.forEach { a.put(JSONObject().put("p", it.first).put("c", it.second)) } }.toString())
    }

    /** [s] ya viene normalizado (minúsculas, sin acentos). Lo que calcula o deduce queda registrado en el cerebro. */
    fun local(s: String): String? {
        val r = localCore(s) ?: return null
        if (r.startsWith("Aprendí la regla")) CodeLab.fromRule(ctx, s)
        if (r.startsWith("Aprendí la regla") || r.startsWith("Entonces ") || r.startsWith("Con lo que sé")) Mind.thought(ctx, "regla", s, r)
        else if (r.startsWith("El resultado") || r.startsWith("Con ") || r.startsWith("Arriesgando") || r.startsWith("Tu ratio")) Mind.calc(ctx, s, r)
        return r
    }

    private fun localCore(s: String): String? {
        // --- reglas: consultar ---
        Regex("^si (.+?) (entonces que|que pasa|que pasaria|que sigue|que conclusion)\\??$").find(s)?.let { m ->
            val out = infer(m.groupValues[1])
            return if (out.isEmpty()) "Con lo que sé, no puedo concluir nada de eso todavía." else "Entonces " + out.joinToString(", y luego ")
        }
        // --- reglas: enseñar ---
        Regex("^si (.+?) entonces (.+)").find(s)?.let { m ->
            rules.add(m.groupValues[1] to m.groupValues[2]); saveRules()
            return "Aprendí la regla: si ${m.groupValues[1]}, entonces ${m.groupValues[2]}."
        }

        val nums = Regex("-?\\d+(?:[.,]\\d+)?").findAll(s).map { it.value.replace(',', '.').toDouble() }.toList()

        // --- finanzas / trading ---
        if (s.contains("interes compuesto") && nums.size >= 3) {
            val (c, r, n) = nums
            val total = c * Math.pow(1 + r / 100, n)
            return "Con ${fmt(c)} al ${fmt(r)}% anual durante ${fmt(n)} años tendrías ${fmt(total)}, es decir ${fmt(total - c)} de ganancia, si reinviertes todo."
        }
        if ((s.contains("tamano de posicion") || s.contains("cuanto arriesgo") || s.contains("cuanto debo arriesgar")) && nums.size >= 3) {
            val (cuenta, riesgoPct, stop) = nums
            val dinero = cuenta * riesgoPct / 100
            return "Arriesgando ${fmt(riesgoPct)}% de ${fmt(cuenta)} pierdes como máximo ${fmt(dinero)} si salta el stop. Con un stop de ${fmt(stop)} puntos, tu posición debe valer ${fmt(dinero / stop)} por punto."
        }
        if (s.contains("riesgo beneficio") && nums.size >= 3) {
            val (e, st, o) = nums
            val risk = Math.abs(e - st); if (risk == 0.0) return "El stop no puede ser igual a la entrada."
            val ratio = Math.abs(o - e) / risk
            val verdict = if (ratio >= 2) "es una relación aceptable." else "es baja; busca al menos 1 a 2."
            return "Tu ratio riesgo beneficio es 1 a ${fmt(ratio)}; $verdict"
        }

        // --- matemáticas ---
        var m = " $s "
        m = m.replace(" mas ", "+").replace(" menos ", "-").replace(" por ", "*").replace(" multiplicado por ", "*")
            .replace(" entre ", "/").replace(" dividido por ", "/").replace(" dividido ", "/")
            .replace(" elevado a ", "^").replace(" al cuadrado", "^2").replace(" por ciento", "%")
        m = m.replace(Regex("(cuanto es|cuanto da|cuanto son|calcula|resuelve|dime cuanto es)"), "").replace(" ", "").replace(",", ".")
        if (m.isNotEmpty() && m.matches(Regex("[0-9+\\-*/().^%]+")) && m.any { it.isDigit() } && m.any { it in "+-*/^%" }) {
            try { return "El resultado es " + fmt(Parser(m).parse()) } catch (_: Exception) {}
        }
        return null
    }

    /** Encadenamiento hacia adelante sobre las reglas aprendidas (hasta 6 pasos). */
    private fun infer(premise: String): List<String> {
        var known = Brain.tokens(premise); val out = mutableListOf<String>(); val used = mutableSetOf<Int>()
        repeat(6) {
            val idx = rules.indices.firstOrNull { i -> i !in used && Brain.tokens(rules[i].first).let { it.isNotEmpty() && known.containsAll(it) } } ?: return out
            used.add(idx); out.add(rules[idx].second); known = known + Brain.tokens(rules[idx].second)
        }
        return out
    }

    private fun online(): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /** Lo que Génesis sabe del usuario (nombre, gustos); lo rellena el motor de comandos. */
    var profile: String = ""

    /** Razonamiento profundo con un modelo de lenguaje (requiere clave de API y internet). */
    fun think(q: String): String? {
        val key = Prefs.apiKey(ctx); if (key.isNullOrBlank() || !online()) return null
        return try {
            val known = brain.recall(q)
            val system = "Eres Génesis, el asistente de voz personal del usuario en su celular. Responde siempre en español, " +
                "claro y breve (máximo 3 frases), pensado para leerse en voz alta, sin markdown ni listas. " +
                "Razona con cuidado y da solo la conclusión útil. En finanzas y trading enseña con rigor y recuerda el riesgo. " +
                "En temas de relaciones, fomenta el respeto y el consentimiento. " +
                "Conversa de forma natural y variada: no repitas frases, cambia el tono y las expresiones, y usa el nombre del usuario solo de vez en cuando. " +
                (if (profile.isNotBlank()) "Lo que sabes del usuario: $profile. " else "") +
                (if (known != null) " Datos de tu memoria que pueden ayudar: $known" else "")
            val msgs = JSONArray()
            history.takeLast(5).forEach { (u, a) ->
                msgs.put(JSONObject().put("role", "user").put("content", u))
                msgs.put(JSONObject().put("role", "assistant").put("content", a))
            }
            msgs.put(JSONObject().put("role", "user").put("content", q))
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 400)
                .put("system", system).put("messages", msgs)
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 10000; c.readTimeout = 30000
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode != 200) return null
            val ans = JSONObject(c.inputStream.bufferedReader().readText())
                .getJSONArray("content").getJSONObject(0).getString("text").trim()
            if (ans.isBlank()) return null
            history.add(q to ans); brain.teach(q, ans)      // aprende: queda guardado para usarlo sin internet
            Mind.thought(ctx, "razonamiento", q, ans)
            ans
        } catch (_: Exception) { null }
    }

    private fun fmt(d: Double): String = if (d == Math.floor(d) && Math.abs(d) < 1e12) d.toLong().toString() else "%.2f".format(d).trimEnd('0').trimEnd('.')

    /** Evaluador de expresiones: + - * / ^ ( ) y porcentaje. */
    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i < s.length) throw IllegalStateException(); return v }
        fun expr(): Double { var v = term(); while (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val r = term(); v = if (o == '+') v + r else v - r }; return v }
        fun term(): Double { var v = pow(); while (i < s.length && (s[i] == '*' || s[i] == '/')) { val o = s[i++]; val r = pow(); v = if (o == '*') v * r else v / r }; return v }
        fun pow(): Double { val b = unary(); if (i < s.length && s[i] == '^') { i++; return Math.pow(b, pow()) }; return b }
        fun unary(): Double { if (i < s.length && s[i] == '-') { i++; return -unary() }; return atom() }
        fun atom(): Double {
            var v: Double
            if (i < s.length && s[i] == '(') { i++; v = expr(); if (i >= s.length || s[i] != ')') throw IllegalStateException(); i++ }
            else { val st = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++; if (st == i) throw IllegalStateException(); v = s.substring(st, i).toDouble() }
            while (i < s.length && s[i] == '%') { i++; v /= 100 }
            return v
        }
    }
}
