package com.jarvis.assistant

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

/**
 * Micrófono SIN pitido.
 * El reconocedor de voz de Google reproduce un "bip" cada vez que abre o cierra el micrófono, y Génesis lo reabre
 * constantemente. Aquí se silencia el canal de MEDIOS solo durante ~1 s alrededor de cada apertura y se devuelve
 * a como estaba. Reglas de seguridad:
 *  - Si estás escuchando música, NO se toca (para no cortártela).
 *  - Si el canal ya estaba silenciado por ti, no se toca (y por tanto no se des-silencia).
 *  - Los canales de timbre/notificación NO se tocan: en muchos celulares están enlazados al modo vibrar y silenciarlos
 *    cambiaría el modo del teléfono.
 *  - Cuando Génesis va a hablar se restaura al instante, para que su voz nunca quede muda.
 */
object Quiet {
    private val main = Handler(Looper.getMainLooper())
    private var am: AudioManager? = null
    private var mutedByUs = false
    private val restore = Runnable { release() }

    /** Silencia el bip del micrófono durante [ms] milisegundos. Llamar justo antes de abrir/cerrar el micrófono. */
    fun hush(c: Context, ms: Long = 1000L) {
        try {
            val a = am ?: (c.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { am = it }
            if (!mutedByUs && !a.isMusicActive && !a.isStreamMute(AudioManager.STREAM_MUSIC)) {
                a.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                mutedByUs = true
            }
        } catch (_: Exception) {}
        main.removeCallbacks(restore)
        if (mutedByUs) main.postDelayed(restore, ms)
    }

    /** Devuelve el sonido a como estaba (no hace nada si nosotros no lo silenciamos). */
    fun release() {
        main.removeCallbacks(restore)
        if (!mutedByUs) return
        mutedByUs = false
        try { am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0) } catch (_: Exception) {}
    }
}
