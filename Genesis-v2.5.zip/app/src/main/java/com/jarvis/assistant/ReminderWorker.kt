package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.work.Worker
import androidx.work.WorkerParameters

/** Se ejecuta a la hora del recordatorio: solo notificación. Génesis no habla sola. */
class ReminderWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
    override fun doWork(): Result {
        val text = inputData.getString("text") ?: return Result.success()
        Extras.dropReminder(applicationContext, inputData.getString("id"))
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("recordatorios", "Recordatorios", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(applicationContext, "recordatorios")
            .setContentTitle("Recordatorio").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setAutoCancel(true).build()
        nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        return Result.success()
    }
}
