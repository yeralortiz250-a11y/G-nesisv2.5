package com.jarvis.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * "¿Qué has aprendido?" y "enséñame cómo sabes sumar".
 *  - report(): cuenta TODO lo que lleva aprendido (habilidades, cálculos, reglas, respuestas, datos tuyos, temas, código…).
 *  - handle(): si preguntas por algo que aprendió (o lo mencionas justo después del resumen), explica de dónde lo
 *    aprendió y cómo se hace paso a paso. Lo que dice es verdad: describe cómo está programada, no inventa estudios.
 */
object Saber {
    const val CREADOR = "Geraldino Ortiz"

    private class Skill(
        val words: Regex, val nombre: String, val origen: String, val pasos: String,
        val cmd: Boolean = false,        // habilidad de comandos del celular: solo se explica si preguntas "cómo"
        val fn: String? = null           // función de código que escribe al aprenderla
    )

    private val SKILLS = listOf(
        Skill(Regex("""interes\w* compuesto"""), "el interés compuesto",
            "Aprendí el interés compuesto porque $CREADOR me enseñó la fórmula de las finanzas.",
            "Se hace así: al capital le aplicas uno más la tasa dividida entre cien, elevado al número de años. Por ejemplo, mil al ocho por ciento durante diez años da dos mil ciento cincuenta y nueve, si reinviertes todo. Dime, por ejemplo: interés compuesto 1000 8 10.",
            fn = "interes compuesto"),
        Skill(Regex("""tamano de posicion|cuanto arriesg\w*|cuanto debo arriesgar"""), "el tamaño de posición",
            "Lo aprendí de las reglas de gestión de riesgo que me dio $CREADOR.",
            "Se hace así: primero calculas cuánto dinero aceptas perder, que es tu cuenta por el porcentaje de riesgo. Después lo divides entre los puntos de tu stop, y eso te dice cuánto vale cada punto de tu posición.",
            fn = "tamano de posicion"),
        Skill(Regex("""riesgo (y )?beneficio"""), "la relación riesgo beneficio",
            "La aprendí de las reglas de trading que me enseñó $CREADOR.",
            "Se hace así: restas la entrada menos el stop para saber cuánto arriesgas. Restas el objetivo menos la entrada para saber cuánto puedes ganar. Divides la ganancia entre el riesgo. Si el resultado es dos o más, es una relación aceptable.",
            fn = "riesgo beneficio"),
        Skill(Regex("""\b(porcentaje\w*|por ciento|porciento)\b"""), "los porcentajes",
            "Aprendí los porcentajes porque mi evaluador de cuentas entiende el símbolo de porcentaje.",
            "Se hace así: un porcentaje es una fracción de cien. Para sacar el veinte por ciento de ochenta, divides veinte entre cien y lo multiplicas por ochenta, y da dieciséis.",
            fn = "porcentaje"),
        Skill(Regex("""\b(potenc\w*|elevad\w*|exponent\w*|al cuadrado)\b"""), "las potencias",
            "Aprendí las potencias porque mi evaluador de cuentas reconoce el símbolo de elevar.",
            "Se hace así: multiplicas la base por sí misma tantas veces como indique el exponente. Tres elevado a cuatro es tres por tres por tres por tres, y da ochenta y uno.",
            fn = "potencia"),
        Skill(Regex("""\b(multiplic\w*|tablas?)\b"""), "multiplicar",
            "Aprendí a multiplicar igual que a sumar: $CREADOR me enseñó a entender cuentas dichas con palabras y a resolverlas con un evaluador de expresiones.",
            "Se hace así: cambio la palabra por por el símbolo de multiplicar y repito la suma del número tantas veces como diga el otro. Quince por ocho es sumar quince ocho veces, y da ciento veinte. Si la cuenta mezcla operaciones, primero multiplico y divido, y luego sumo y resto.",
            fn = "multiplicar"),
        Skill(Regex("""\b(divid\w*|division)\b"""), "dividir",
            "Aprendí a dividir de la misma forma que a sumar, con mi evaluador de cuentas.",
            "Se hace así: reparto el primer número en tantas partes iguales como diga el segundo. Cien entre cuatro da veinticinco. Entre cero no se puede dividir, y si me lo pides te lo aviso.",
            fn = "dividir"),
        Skill(Regex("""\b(rest(a|as|ar|o|ando)|sustraccion)\b"""), "restar",
            "Aprendí a restar igual que a sumar: $CREADOR me enseñó a convertir las palabras en símbolos y a resolver la cuenta.",
            "Se hace así: cambio la palabra menos por el símbolo de resta y quito del primer número lo que diga el segundo. Cincuenta menos doce da treinta y ocho.",
            fn = "restar"),
        Skill(Regex("""\b(sum(a|as|ar|o|ando)|adicion)\b"""), "sumar",
            "Aprendí a sumar porque $CREADOR me enseñó a entender cuentas dichas con palabras, como quince más ocho, y a resolverlas con un evaluador de expresiones.",
            "Se hace así: uno, cambio la palabra más por el símbolo de sumar. Dos, junto los números. Tres, voy sumando de izquierda a derecha. Quince más ocho da veintitrés. Si la cuenta tiene multiplicaciones o divisiones, esas las hago primero y después sumo.",
            fn = "sumar"),
        Skill(Regex("""\b(reglas?|deduc\w*|razon\w*|inferi\w*|si entonces)\b"""), "razonar con reglas",
            "Aprendí a razonar con reglas porque tú me las enseñas y yo las encadeno.",
            "Se hace así: me dices, por ejemplo, si sube la inflación entonces suben las tasas, y yo la guardo. Después, si me preguntas si sube la inflación qué pasa, busco las reglas cuya condición se cumple, las encadeno hasta seis pasos y te doy la conclusión."),
        Skill(Regex("""\b(corrig\w*|correccion\w*|corrijo|equivocas)\b"""), "corregirme",
            "Aprendí a corregirme porque tú me lo enseñaste.",
            "Se hace así: cuando digo algo mal, me dices eso está mal, la respuesta es, y lo correcto. Guardo tu respuesta en mi memoria y la próxima vez que me hagan esa pregunta contesto lo que me enseñaste."),
        Skill(Regex("""\b(ensenanzas?|ensenadas?|respuestas? que te)\b"""), "responder lo que me enseñas",
            "Lo aprendí porque $CREADOR me dio una memoria de respuestas que tú puedes llenar.",
            "Se hace así: me dices cuando te diga una cosa responde otra, y yo guardo la pareja. Cuando la dices, lo busco primero en esa memoria y contesto lo que me enseñaste."),
        Skill(Regex("""\b(conocerme|mi nombre|datos (mios|personales)|gustos)\b"""), "recordar tus datos",
            "Aprendí a recordarte porque escucho lo que me cuentas.",
            "Se hace así: cuando dices me llamo Ana, o mi comida favorita es la pizza, o vivo en Lima, reconozco la frase, saco el dato y lo guardo en tu perfil. Después, si me preguntas, te lo digo."),
        Skill(Regex("""\b(wikipedia|internet|buscar|investigar|estudiar)\b"""), "buscar y estudiar en internet",
            "Aprendí a buscar porque $CREADOR me conectó a Wikipedia y a buscadores.",
            "Se hace así: si no sé algo, te aviso que voy a pensar, busco hasta cinco segundos en varias fuentes a la vez y guardo la respuesta en mi cerebro. Así la próxima vez la sé sin internet. Si no hay conexión, la anoto y la estudio después."),
        Skill(Regex("""\b(aprender sola|aprendizaje automatico|aprender de todo|articulos)\b"""), "aprender sola",
            "Aprendí a estudiar sola porque $CREADOR me dio un aprendizaje automático en segundo plano.",
            "Se hace así: con internet y batería suficiente, leo artículos completos de Wikipedia, los troceo y los guardo en mi cerebro. De cada artículo sigo sus enlaces hacia temas relacionados, y de vez en cuando abro uno al azar para abarcar de todo."),
        Skill(Regex("""\b(diccionario|significado|definiciones?)\b"""), "el diccionario",
            "Aprendí palabras porque descargo el diccionario Wiktionario poco a poco.",
            "Se hace así: cuando me preguntas qué significa una palabra, la busco primero en mi diccionario guardado y, si no está y hay internet, la busco y la guardo."),
        Skill(Regex("""\b(codigo|programar|programas?|funciones?)\b"""), "escribir mi propio código",
            "Aprendí a programar porque $CREADOR me dio un taller de código.",
            "Se hace así: cada vez que aprendo un cálculo, una regla, una respuesta o un comando, lo convierto en líneas de código y las guardo en mi cerebro. Las cuentas además las ejecuto en una caja segura para comprobar que me salen bien. Con la clave de IA puedo escribir un programa nuevo y ejecutarlo si me dices: escribe código para, y lo que quieras. Sin clave puedo ejecutar mis funciones: di ejecuta sumar 15 y 8. Mi caja segura solo hace cuentas y lógica: no puede llamar, mandar mensajes ni tocar tu celular."),
        Skill(Regex("""\b(llamar|llamadas?|llamas|marcar)\b"""), "llamar",
            "Aprendí a llamar porque $CREADOR me dio permiso para usar tus contactos y el teléfono.",
            "Se hace así: cuando dices llama a mami, busco ese nombre en tus contactos, tomo su número y marco. Si el contacto no existe, te lo digo.", cmd = true),
        Skill(Regex("""\b(volumen|sonido)\b"""), "manejar el volumen",
            "Aprendí a manejar el volumen porque $CREADOR me conectó al control de audio del celular.",
            "Se hace así: reconozco si pides subir, bajar, silenciar o un porcentaje, y le doy esa orden al control de volumen de Android.", cmd = true),
        Skill(Regex("""\b(mensajes?|whatsapp|sms)\b"""), "mandar mensajes",
            "Aprendí a mandar mensajes porque $CREADOR me dio acceso al SMS y a WhatsApp.",
            "Se hace así: separo a quién va y qué quieres decir, busco al contacto, y mando el SMS o preparo el WhatsApp y pulso enviar.", cmd = true)
    )

    // Preguntas por lo aprendido (la de "de mi" la atiende Persona)
    private val REPORT = Regex("""\b(que (has|haz|ha|he) aprendido|que aprendiste|que has estudiado|que estudiaste|todo lo que (has )?aprendido|lo que (has )?aprendido|cuanto has aprendido|que mas has aprendido)\b""")
    private val EXPLAIN = Regex("""\b(ensename|explicame|muestrame|cuentame|dime|como (aprendiste|aprendes|sabes|haces|lo haces|resuelves|calculas|se hace|se hacen|se hizo|funciona)|de que forma|que sabes (de|sobre|acerca de)|sabes)\b""")
    private val TOPIC = Regex("""^(?:(?:ensename|explicame|cuentame|dime) )?(?:como (?:aprendiste|sabes)|que sabes (?:de|sobre|acerca de)) (?:a |de |sobre |acerca de )?(.+)$""")

    /** Momento del último resumen: durante 3 minutos, mencionar algo de lo aprendido basta para que lo explique. */
    @Volatile private var reportAt = 0L

    /** [s] ya viene normalizado. Devuelve null si no es una pregunta sobre lo aprendido. */
    fun handle(c: Context, brain: Brain, s: String): String? {
        if (s.endsWith(" de mi") || s.endsWith(" sobre mi") || s.endsWith(" mi")) return null     // "qué sabes de mí": lo atiende Persona
        if (REPORT.containsMatchIn(s)) return report(c, brain)
        if (Regex("^(?:como|de que forma) (?:aprendes|aprendiste|es que aprendes)$").matches(s)) return howGeneral()

        if (Regex("\\d").containsMatchIn(s)) return null              // con números es una cuenta ("dime cuánto es 20 por ciento de 80"): se calcula, no se explica

        val explain = EXPLAIN.containsMatchIn(s)
        val recent = System.currentTimeMillis() - reportAt < 180_000L && s.split(" ").size <= 6
        if (!explain && !recent) return null
        val sk = SKILLS.firstOrNull { (!it.cmd || s.contains("como")) && it.words.containsMatchIn(s) }
        if (sk != null) return describe(c, sk)

        // Algo aprendido que no es una habilidad: de dónde salió y qué guardó
        TOPIC.find(s)?.let { m -> return aboutTopic(c, brain, m.groupValues[1].trim()) }
        return null
    }

    private fun describe(c: Context, sk: Skill): String {
        val sb = StringBuilder("Te cuento cómo aprendí ${sk.nombre}. ").append(sk.origen).append(' ').append(sk.pasos)
        if (sk.fn != null) {
            CodeLab.ensureFunction(c, sk.fn)          // al explicarlo, también lo escribe como código propio
            val n = Mind.calcTotal(c)
            if (n > 0) sb.append(" Hasta ahora he resuelto $n cálculos.")
            sb.append(" Escribí mi propia función de código para esto. Dime: muestra tu código, para verla.")
        }
        return sb.toString()
    }

    private fun howGeneral(): String =
        "Aprendo de cinco formas. Una: de lo que tú me cuentas y me enseñas. Dos: de tus correcciones. " +
        "Tres: buscando en internet lo que no sé y guardándolo. Cuatro: estudiando sola artículos de Wikipedia en segundo plano. " +
        "Cinco: convirtiendo lo que aprendo en código propio. Lo hago así porque $CREADOR me programó de esa manera. Pregúntame por algo concreto, como sumar."

    private fun aboutTopic(c: Context, brain: Brain, topic: String): String? {
        if (topic.length < 3) return null
        val known = brain.recall(topic) ?: return null                 // solo si de verdad lo tiene (coincidencia comprobada)
        val src = Mind.provenance(c, topic)
        val where = if (src != null) "Lo aprendí de ${src[1]}, en el tema ${src[0]}, el ${src[2]}."
                    else "Lo tengo en mi memoria, de mis lecciones o de lo que me enseñaste."
        return "$where Esto es lo que guardé: " + Net.sentences(known, 300)
    }

    // ---------- Resumen de todo lo aprendido ----------

    private fun objCount(c: Context, f: String): Int = try {
        val file = c.getFileStreamPath(f); if (file.exists()) JSONObject(file.readText()).length() else 0
    } catch (_: Exception) { 0 }

    private fun arrCount(c: Context, f: String): Int = try {
        val file = c.getFileStreamPath(f); if (file.exists()) JSONArray(file.readText()).length() else 0
    } catch (_: Exception) { 0 }

    private fun lineCount(c: Context, f: String): Int = try {
        val file = c.getFileStreamPath(f); if (file.exists()) file.readLines().count { it.isNotBlank() } else 0
    } catch (_: Exception) { 0 }

    fun report(c: Context, brain: Brain): String {
        reportAt = System.currentTimeMillis()
        val p = ArrayList<String>()
        p += "Esto es todo lo que he aprendido hasta ahora."
        p += "Habilidades: sé sumar, restar, multiplicar, dividir, sacar potencias y porcentajes, calcular interés compuesto, " +
            "tamaño de posición y riesgo beneficio, razonar con reglas, llamar, mandar mensajes, manejar el volumen, " +
            "buscar en internet, conversar, y escribir y ejecutar mi propio código."
        val calcs = Mind.calcTotal(c); if (calcs > 0) p += "He resuelto $calcs cálculos."
        val rules = arrCount(c, "rules.json"); if (rules > 0) p += "Me enseñaste $rules reglas."
        val ans = objCount(c, "respuestas.json"); if (ans > 0) p += "Aprendí $ans respuestas que me enseñaste o me corregiste."
        val cmds = brain.customCount(); if (cmds > 0) p += "Tengo $cmds comandos propios."
        val perfil = objCount(c, "perfil.json"); if (perfil > 0) p += "Sé $perfil datos sobre ti."

        val facts = brain.learnedCount(); val kb = Mind.kbCount(c); val topics = Mind.topicCount(c); val arts = Prefs.turboArticles(c)
        if (facts + kb > 0)
            p += "En mi memoria tengo $facts conocimientos básicos y $kb fragmentos de $topics temas" +
                (if (arts > 0) ", de $arts artículos de Wikipedia" else "") + "."
        else p += "Todavía no he estudiado temas nuevos."
        val rec = Mind.recentTopics(c, 5)
        if (rec.isNotEmpty()) p += "Lo último que estudié: " + rec.joinToString(", ") + "."
        val words = Vocab.count(c); if (words > 0) p += "Conozco $words palabras de mi diccionario."
        val pend = lineCount(c, "pending.txt"); if (pend > 0) p += "Tengo $pend temas anotados para estudiar."
        val code = Mind.codeCount(c)
        if (code > 0) p += "He escrito ${Mind.codeLines(c)} líneas de código propio en $code fragmentos."
        p += "Pregúntame, por ejemplo: enséñame cómo sabes sumar, y te explico cómo lo aprendí y cómo se hace."
        return p.joinToString(" ")
    }
}
